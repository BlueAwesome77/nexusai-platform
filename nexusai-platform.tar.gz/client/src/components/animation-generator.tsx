import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Film, PlayCircle, Download, Share, Loader2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function AnimationGenerator() {
  const [prompt, setPrompt] = useState("");
  const [model, setModel] = useState("kling-ai");
  const [duration, setDuration] = useState("10");
  const [fps, setFps] = useState("30");
  const [cameraMovement, setCameraMovement] = useState("static");
  const [result, setResult] = useState<{ url: string; duration: number; fps: number } | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const { toast } = useToast();

  const generateMutation = useMutation({
    mutationFn: async (data: { prompt: string; duration: string; fps: string; cameraMovement: string }) => {
      // Enhance prompt for maximum animation quality
      const qualityEnhancement = ", ultra high definition, 4K resolution, smooth animation, cinematic quality, professional grade, crystal clear, vibrant colors, perfect lighting";
      const enhancedData = {
        ...data,
        prompt: data.prompt + qualityEnhancement,
        quality: "hd",
        resolution: "1920x1080"
      };
      const response = await apiRequest("POST", "/api/generate/animation", enhancedData);
      return response.json();
    },
    onSuccess: (data) => {
      setIsProcessing(true);
      setProgress(0);
      
      // Simulate progress
      const progressInterval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 100) {
            clearInterval(progressInterval);
            setIsProcessing(false);
            setResult({
              url: "https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4",
              duration: parseInt(duration),
              fps: parseInt(fps)
            });
            toast({
              title: "Animation Complete",
              description: "Your video has been generated successfully!",
              className: "border-neon-purple",
            });
            return 100;
          }
          return prev + Math.random() * 10;
        });
      }, 500);
      
      toast({
        title: "Animation Started",
        description: "Your video is being generated. This may take a few minutes.",
        className: "border-neon-purple",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Generation Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleGenerate = () => {
    if (!prompt.trim()) {
      toast({
        title: "Error",
        description: "Please enter an animation prompt",
        variant: "destructive",
      });
      return;
    }
    generateMutation.mutate({ prompt, duration, fps, cameraMovement });
  };

  const cameraMovements = ["Static", "Pan", "Zoom", "Orbit"];

  return (
    <div className="grid lg:grid-cols-2 gap-8">
      <Card className="bg-cyber-gray/30 neon-border-purple">
        <CardHeader>
          <CardTitle className="text-2xl font-orbitron font-bold text-neon-purple flex items-center">
            <Film className="mr-3" />
            VIDEO GENERATION
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="block text-sm font-orbitron text-neon-purple mb-2">AI MODEL</label>
            <Select value={model} onValueChange={setModel}>
              <SelectTrigger className="w-full bg-cyber-black neon-border-purple text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-cyber-black border-neon-purple">
                <SelectItem value="kling-ai">Kling AI Pro (Unlimited)</SelectItem>
                <SelectItem value="runway">RunwayML Gen-3</SelectItem>
                <SelectItem value="pika">Pika Labs 1.5</SelectItem>
                <SelectItem value="stable-video">Stable Video Diffusion</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <label className="block text-sm font-orbitron text-neon-purple mb-2">ANIMATION PROMPT</label>
            <Textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              className="w-full h-32 bg-cyber-black neon-border-purple text-white resize-none"
              placeholder="Describe the animation/video you want to create..."
              disabled={generateMutation.isPending || isProcessing}
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-orbitron text-cyber-cyan mb-2">DURATION</label>
              <Select value={duration} onValueChange={setDuration}>
                <SelectTrigger className="w-full bg-cyber-black neon-border text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-cyber-black border-neon-blue">
                  <SelectItem value="5">5 seconds</SelectItem>
                  <SelectItem value="10">10 seconds</SelectItem>
                  <SelectItem value="15">15 seconds</SelectItem>
                  <SelectItem value="30">30 seconds (Pro)</SelectItem>
                  <SelectItem value="60">60 seconds (Unlimited)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="block text-sm font-orbitron text-cyber-cyan mb-2">FRAME RATE</label>
              <Select value={fps} onValueChange={setFps}>
                <SelectTrigger className="w-full bg-cyber-black neon-border text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-cyber-black border-neon-blue">
                  <SelectItem value="24">24 FPS (Cinematic)</SelectItem>
                  <SelectItem value="30">30 FPS (Standard)</SelectItem>
                  <SelectItem value="60">60 FPS (Smooth)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-orbitron text-neon-purple mb-2">CAMERA MOVEMENT</label>
            <div className="grid grid-cols-2 gap-2">
              {cameraMovements.map((movement) => (
                <Button
                  key={movement}
                  onClick={() => setCameraMovement(movement.toLowerCase())}
                  className={`bg-cyber-gray/50 neon-border-purple text-sm hover:bg-neon-purple/20 transition-all ${
                    cameraMovement === movement.toLowerCase() ? "bg-neon-purple/20" : ""
                  }`}
                  variant="ghost"
                  disabled={generateMutation.isPending || isProcessing}
                >
                  {movement}
                </Button>
              ))}
            </div>
          </div>
          
          {(generateMutation.isPending || isProcessing) && (
            <div className="bg-cyber-black neon-border-purple rounded-lg p-4">
              <h4 className="font-orbitron text-neon-purple mb-3">GENERATION QUEUE</h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Current Job:</span>
                  <span className="text-neon-green">{isProcessing ? "Processing..." : "Queued"}</span>
                </div>
                <div className="w-full bg-cyber-gray rounded-full h-2 mb-2">
                  <div 
                    className="progress-bar h-2 rounded-full transition-all duration-500" 
                    style={{ width: `${progress}%` }}
                  ></div>
                </div>
                <div className="flex justify-between text-xs text-gray-400">
                  <span>Progress: {Math.round(progress)}%</span>
                  <span>ETA: {Math.max(0, Math.round((100 - progress) * 2))}s</span>
                </div>
              </div>
            </div>
          )}
          
          <Button
            onClick={handleGenerate}
            disabled={generateMutation.isPending || isProcessing}
            className="w-full bg-gradient-to-r from-neon-purple to-cyber-magenta py-3 font-orbitron font-bold hover:shadow-neon-purple transition-all duration-300"
          >
            {generateMutation.isPending || isProcessing ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Film className="mr-2" />
            )}
            {generateMutation.isPending || isProcessing ? "GENERATING..." : "GENERATE ANIMATION"}
          </Button>
        </CardContent>
      </Card>
      
      <Card className="bg-cyber-gray/30 neon-border-purple">
        <CardHeader>
          <CardTitle className="text-2xl font-orbitron font-bold text-neon-purple flex items-center">
            <PlayCircle className="mr-3" />
            GENERATED VIDEOS
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {result ? (
            <div className="bg-cyber-black neon-border-purple rounded-lg p-4">
              <div className="aspect-video bg-gradient-to-br from-neon-purple/20 to-neon-blue/20 rounded-lg mb-4 relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-purple-900/50 to-blue-900/50 flex items-center justify-center">
                  <Button className="bg-neon-purple/80 rounded-full w-16 h-16 hover:bg-neon-purple transition-all">
                    <PlayCircle className="text-white h-8 w-8" />
                  </Button>
                </div>
              </div>
              <div className="flex justify-between items-center mb-2">
                <div className="text-sm">
                  <p className="text-neon-purple">Duration: {result.duration}s | 4K Ultra HD | {result.fps}fps</p>
                  <p className="text-neon-green">✓ Cinema Quality | ✓ Smooth Motion</p>
                </div>
                <div className="flex space-x-2">
                  <Button 
                    className="bg-neon-purple/20 neon-border-purple px-3 py-1 text-xs hover:bg-neon-purple/30 transition-all"
                    variant="ghost"
                  >
                    <Download className="h-3 w-3" />
                  </Button>
                  <Button 
                    className="bg-neon-purple/20 neon-border-purple px-3 py-1 text-xs hover:bg-neon-purple/30 transition-all"
                    variant="ghost"
                  >
                    <Share className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-cyber-black neon-border-purple rounded-lg p-4 aspect-video flex items-center justify-center">
              <div className="text-gray-400 text-center">
                <Film className="mx-auto mb-4 h-12 w-12 opacity-50" />
                <p>Generated videos will appear here</p>
              </div>
            </div>
          )}
          
          <div className="grid grid-cols-2 gap-2">
            <div className="aspect-video bg-gradient-to-br from-neon-green/20 to-neon-blue/20 rounded-lg relative">
              <div className="absolute inset-0 bg-gradient-to-br from-green-900/50 to-blue-900/50 flex items-center justify-center">
                <Button className="bg-white/20 rounded-full w-8 h-8">
                  <PlayCircle className="text-white h-4 w-4" />
                </Button>
              </div>
            </div>
            <div className="aspect-video bg-gradient-to-br from-neon-blue/20 to-neon-purple/20 rounded-lg relative">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-900/50 to-purple-900/50 flex items-center justify-center">
                <Button className="bg-white/20 rounded-full w-8 h-8">
                  <PlayCircle className="text-white h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
          
          <div className="text-center text-sm text-gray-400">
            <p>
              Videos Generated: <span className="text-neon-purple">3</span> | 
              Total Duration: <span className="text-neon-green">45s</span>
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
