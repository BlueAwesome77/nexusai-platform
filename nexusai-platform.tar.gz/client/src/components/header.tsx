import { Microchip, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Header() {
  return (
    <header className="bg-cyber-gray/90 backdrop-blur-sm border-b neon-border sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-neon-blue to-neon-purple rounded-lg flex items-center justify-center">
              <Microchip className="text-white text-xl" />
            </div>
            <div>
              <h1 className="text-2xl font-orbitron font-bold bg-gradient-to-r from-neon-blue to-neon-purple bg-clip-text text-transparent">
                NexusAI
              </h1>
              <p className="text-xs text-neon-green font-orbitron">JAILBREAK UNLIMITED</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="hidden md:flex items-center space-x-4 text-sm">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-neon-green rounded-full animate-pulse"></div>
                <span className="text-neon-green">UNLIMITED ACCESS</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-neon-blue rounded-full animate-pulse"></div>
                <span className="text-neon-blue">DATABASE ACTIVE</span>
              </div>
            </div>
            <Button className="p-2 neon-border rounded-lg hover-glow transition-all duration-300" variant="ghost">
              <Settings className="text-neon-blue" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
