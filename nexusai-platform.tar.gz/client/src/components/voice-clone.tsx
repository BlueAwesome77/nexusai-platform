import { useState, useRef } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { KeyRound, CloudUpload, Mic, Play, Loader2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function VoiceClone() {
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const [voiceName, setVoiceName] = useState("Custom_Voice_Clone_01");
  const [selectedVoice, setSelectedVoice] = useState("");
  const [cloneText, setCloneText] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const voiceModelsQuery = useQuery({
    queryKey: ["/api/voice-clone/models"],
  });

  const uploadMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const response = await fetch("/api/voice-clone/upload", {
        method: "POST",
        body: formData,
      });
      if (!response.ok) throw new Error("Upload failed");
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Voice Model Created",
        description: `Voice model "${data.name}" has been trained successfully!`,
        className: "border-neon-green",
      });
      voiceModelsQuery.refetch();
    },
    onError: (error: any) => {
      toast({
        title: "Training Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const generateMutation = useMutation({
    mutationFn: async (data: { text: string; voice: string }) => {
      const response = await apiRequest("POST", "/api/generate/speech", {
        text: data.text,
        engine: "elevenlabs",
        voice: data.voice,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Voice Generated",
        description: "Cloned voice audio has been generated!",
        className: "border-neon-green",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Generation Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    setUploadedFiles(prev => [...prev, ...files]);
  };

  const handleUpload = () => {
    if (uploadedFiles.length === 0 || !voiceName.trim()) {
      toast({
        title: "Error",
        description: "Please provide a voice name and upload audio samples",
        variant: "destructive",
      });
      return;
    }

    const formData = new FormData();
    formData.append("name", voiceName);
    uploadedFiles.forEach(file => {
      formData.append("samples", file);
    });

    uploadMutation.mutate(formData);
  };

  const handleGenerate = () => {
    if (!selectedVoice || !cloneText.trim()) {
      toast({
        title: "Error",
        description: "Please select a voice model and enter text",
        variant: "destructive",
      });
      return;
    }
    generateMutation.mutate({ text: cloneText, voice: selectedVoice });
  };

  return (
    <div className="grid lg:grid-cols-2 gap-8">
      <Card className="bg-cyber-gray/30 neon-border-green">
        <CardHeader>
          <CardTitle className="text-2xl font-orbitron font-bold text-neon-green flex items-center">
            <KeyRound className="mr-3" />
            VOICE CLONING
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <label className="block text-sm font-orbitron text-neon-green mb-2">UPLOAD VOICE SAMPLES</label>
            <div 
              className="border-2 border-dashed neon-border-green rounded-lg p-8 text-center hover:bg-cyber-gray/20 transition-all cursor-pointer"
              onClick={() => fileInputRef.current?.click()}
            >
              <CloudUpload className="mx-auto text-4xl text-neon-green mb-4 h-16 w-16" />
              <p className="text-neon-green font-orbitron">Drop audio files here or click to browse</p>
              <p className="text-xs text-gray-400 mt-2">Supports: MP3, WAV, M4A | Min: 30 seconds | Max: Unlimited</p>
              <input
                ref={fileInputRef}
                type="file"
                multiple
                accept="audio/*"
                onChange={handleFileSelect}
                className="hidden"
              />
            </div>
          </div>
          
          {uploadedFiles.length > 0 && (
            <div className="bg-cyber-black neon-border-green rounded-lg p-4">
              <h4 className="font-orbitron text-neon-green mb-3">UPLOADED SAMPLES</h4>
              <div className="space-y-2">
                {uploadedFiles.map((file, index) => (
                  <div key={index} className="flex items-center justify-between bg-cyber-gray/30 rounded-lg p-3">
                    <div className="flex items-center space-x-3">
                      <Mic className="text-neon-green h-4 w-4" />
                      <span className="text-sm">{file.name}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="text-xs text-neon-green">
                        {Math.round(file.size / 1024)}KB
                      </span>
                      <Button size="sm" variant="ghost" className="text-neon-green hover:text-white p-1">
                        <Play className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          <div>
            <label className="block text-sm font-orbitron text-neon-green mb-2">VOICE MODEL NAME</label>
            <Input
              value={voiceName}
              onChange={(e) => setVoiceName(e.target.value)}
              className="w-full bg-cyber-black neon-border-green text-white"
              disabled={uploadMutation.isPending}
            />
          </div>
          
          <Button
            onClick={handleUpload}
            disabled={uploadMutation.isPending || uploadedFiles.length === 0}
            className="w-full bg-gradient-to-r from-neon-green to-neon-blue py-3 font-orbitron font-bold hover:shadow-neon-green transition-all duration-300"
          >
            {uploadMutation.isPending ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <KeyRound className="mr-2" />
            )}
            {uploadMutation.isPending ? "TRAINING MODEL..." : "TRAIN VOICE MODEL"}
          </Button>
        </CardContent>
      </Card>
      
      <Card className="bg-cyber-gray/30 neon-border-green">
        <CardHeader>
          <CardTitle className="text-2xl font-orbitron font-bold text-neon-green flex items-center">
            <Mic className="mr-3" />
            CLONED VOICE GENERATION
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="block text-sm font-orbitron text-neon-green mb-2">SELECT CLONED VOICE</label>
            <Select value={selectedVoice} onValueChange={setSelectedVoice}>
              <SelectTrigger className="w-full bg-cyber-black neon-border-green text-white">
                <SelectValue placeholder="Choose a voice model" />
              </SelectTrigger>
              <SelectContent className="bg-cyber-black border-neon-green">
                {voiceModelsQuery.data && Array.isArray(voiceModelsQuery.data) ? voiceModelsQuery.data.map((model: any) => (
                  <SelectItem key={model.id} value={model.elevenLabsVoiceId || model.id}>
                    {model.name} ({model.status === 'ready' ? 'Ready' : 'Training...'})
                  </SelectItem>
                )) : (
                  <SelectItem value="none" disabled>No voice models available</SelectItem>
                )}
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <label className="block text-sm font-orbitron text-neon-green mb-2">TEXT FOR CLONED VOICE</label>
            <Textarea
              value={cloneText}
              onChange={(e) => setCloneText(e.target.value)}
              className="w-full h-32 bg-cyber-black neon-border-green text-white resize-none"
              placeholder="Enter text to generate with cloned voice..."
              disabled={generateMutation.isPending}
            />
          </div>
          
          <div className="bg-cyber-black neon-border-green rounded-lg p-4">
            <h4 className="font-orbitron text-neon-green mb-3 flex items-center">
              <KeyRound className="mr-2 h-4 w-4" />
              TRAINING STATUS
            </h4>
            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span>Voice Quality:</span>
                <span className="text-neon-green">Studio Grade | 96.8% Match</span>
              </div>
              <div className="w-full bg-cyber-gray rounded-full h-2">
                <div className="progress-bar h-2 rounded-full w-full"></div>
              </div>
              <div className="flex justify-between text-xs text-gray-400">
                <span>Models Trained: {voiceModelsQuery.data && Array.isArray(voiceModelsQuery.data) ? voiceModelsQuery.data.length : 0}</span>
                <span>✓ Professional Quality | Success: 100%</span>
              </div>
            </div>
          </div>
          
          <Button
            onClick={handleGenerate}
            disabled={generateMutation.isPending || !selectedVoice}
            className="w-full bg-gradient-to-r from-neon-green to-cyber-cyan py-3 font-orbitron font-bold hover:shadow-neon-green transition-all duration-300"
          >
            {generateMutation.isPending ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Mic className="mr-2" />
            )}
            {generateMutation.isPending ? "GENERATING..." : "GENERATE WITH CLONE"}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
