export default function Footer() {
  return (
    <footer className="bg-cyber-gray/90 border-t neon-border mt-16">
      <div className="container mx-auto px-4 py-8">
        <div className="grid md:grid-cols-3 gap-8">
          <div>
            <h3 className="font-orbitron font-bold text-neon-blue mb-4">NEXUSAI UNLIMITED</h3>
            <p className="text-gray-400 text-sm">
              Breaking the boundaries of AI content generation. No limits, no restrictions, just pure unlimited creativity.
            </p>
          </div>
          <div>
            <h4 className="font-orbitron text-neon-purple mb-4">POWERED BY</h4>
            <div className="grid grid-cols-2 gap-2 text-sm text-gray-400">
              <span>• OpenAI ChatGPT</span>
              <span>• Grok AI</span>
              <span>• ElevenLabs</span>
              <span>• Leonardo AI</span>
              <span>• Kling AI</span>
              <span>• Play.TTS</span>
            </div>
          </div>
          <div>
            <h4 className="font-orbitron text-neon-green mb-4">STATUS</h4>
            <div className="space-y-2 text-sm">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-neon-green rounded-full animate-pulse"></div>
                <span className="text-neon-green">All Systems Operational</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-neon-blue rounded-full animate-pulse"></div>
                <span className="text-neon-blue">Database Storage Active</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-neon-purple rounded-full animate-pulse"></div>
                <span className="text-neon-purple">Jailbreak Mode: ON</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-cyber-cyan rounded-full animate-pulse"></div>
                <span className="text-cyber-cyan">Persistent Generations</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="border-t border-cyber-gray mt-8 pt-8 text-center">
          <p className="text-gray-400 text-sm font-orbitron">
            © 2024 NexusAI Jailbreak Unlimited. Push the envelope. Break the limits.
          </p>
        </div>
      </div>
    </footer>
  );
}
