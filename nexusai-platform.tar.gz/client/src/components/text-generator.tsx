import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Brain, Terminal, Copy, Download, Rocket, Loader2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function TextGenerator() {
  const [prompt, setPrompt] = useState("");
  const [model, setModel] = useState("gpt-4o");
  const [temperature, setTemperature] = useState([0.8]);
  const [result, setResult] = useState("");
  const { toast } = useToast();

  const generateMutation = useMutation({
    mutationFn: async (data: { prompt: string; model: string; temperature: number }) => {
      // Enhance prompt for higher quality responses
      const qualityEnhancement = data.model.includes("grok") ? 
        " Please provide a comprehensive, well-structured, and detailed response with clear explanations." :
        " Please provide a high-quality, detailed, and well-formatted response.";
      const enhancedData = {
        ...data,
        prompt: data.prompt + qualityEnhancement
      };
      const response = await apiRequest("POST", "/api/generate/text", enhancedData);
      return response.json();
    },
    onSuccess: (data) => {
      setResult(data.text);
      toast({
        title: "Generation Complete",
        description: "Text has been generated successfully!",
        className: "border-neon-green",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Generation Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleGenerate = () => {
    if (!prompt.trim()) {
      toast({
        title: "Error",
        description: "Please enter a prompt",
        variant: "destructive",
      });
      return;
    }
    generateMutation.mutate({ prompt, model, temperature: temperature[0] });
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(result);
    toast({
      title: "Copied",
      description: "Text copied to clipboard",
      className: "border-neon-green",
    });
  };

  return (
    <div className="grid lg:grid-cols-2 gap-8">
      <Card className="bg-cyber-gray/30 neon-border">
        <CardHeader>
          <CardTitle className="text-2xl font-orbitron font-bold text-neon-blue flex items-center">
            <Brain className="mr-3" />
            TEXT GENERATION
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="block text-sm font-orbitron text-neon-blue mb-2">AI MODEL</label>
            <Select value={model} onValueChange={setModel}>
              <SelectTrigger className="w-full bg-cyber-black neon-border text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-cyber-black border-neon-blue">
                <SelectItem value="gpt-4o">ChatGPT-4 Turbo (Jailbroken)</SelectItem>
                <SelectItem value="grok-2-1212">Grok-2 Unlimited</SelectItem>
                <SelectItem value="gpt-3.5-turbo">ChatGPT-3.5 Turbo</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <label className="block text-sm font-orbitron text-neon-blue mb-2">PROMPT</label>
            <Textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              className="w-full h-32 bg-cyber-black neon-border text-white resize-none"
              placeholder="Enter your unlimited prompt... No restrictions, no filters."
              disabled={generateMutation.isPending}
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-orbitron text-neon-purple mb-2">MAX TOKENS</label>
              <input
                type="text"
                value="∞"
                className="w-full bg-cyber-black neon-border-purple rounded-lg p-3 text-white text-center"
                readOnly
              />
            </div>
            <div>
              <label className="block text-sm font-orbitron text-neon-green mb-2">
                TEMPERATURE: {temperature[0]}
              </label>
              <Slider
                value={temperature}
                onValueChange={setTemperature}
                max={2}
                min={0}
                step={0.1}
                className="w-full"
                disabled={generateMutation.isPending}
              />
            </div>
          </div>
          
          <Button
            onClick={handleGenerate}
            disabled={generateMutation.isPending}
            className="w-full bg-gradient-to-r from-neon-blue to-neon-purple py-3 font-orbitron font-bold hover:shadow-neon-blue transition-all duration-300 transform hover:scale-105"
          >
            {generateMutation.isPending ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Rocket className="mr-2" />
            )}
            {generateMutation.isPending ? "GENERATING..." : "GENERATE UNLIMITED"}
          </Button>
        </CardContent>
      </Card>
      
      <Card className="bg-cyber-gray/30 neon-border-green">
        <CardHeader>
          <CardTitle className="text-2xl font-orbitron font-bold text-neon-green flex items-center">
            <Terminal className="mr-3" />
            OUTPUT
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="bg-cyber-black neon-border-green rounded-lg p-4 h-80 overflow-y-auto">
            {generateMutation.isPending ? (
              <div className="text-green-300 font-mono text-sm">
                <div className="flex items-center mb-4">
                  <div className="w-3 h-3 bg-neon-green rounded-full animate-pulse mr-2"></div>
                  <span className="text-neon-green font-orbitron">GENERATION STATUS: ACTIVE</span>
                </div>
                <div className="progress-bar h-1 rounded-full mb-4"></div>
                <p className="text-xs text-gray-400">Processing your request...</p>
              </div>
            ) : result ? (
              <div className="text-green-300 font-mono text-sm whitespace-pre-wrap">
                {result}
              </div>
            ) : (
              <div className="text-gray-400 text-center py-8">
                <Terminal className="mx-auto mb-4 h-12 w-12 opacity-50" />
                <p>Generated content will appear here</p>
              </div>
            )}
          </div>
          
          {result && (
            <div className="flex space-x-2 mt-4">
              <Button
                onClick={copyToClipboard}
                className="flex-1 bg-neon-green/20 neon-border-green font-orbitron text-sm hover:bg-neon-green/30 transition-all"
                variant="ghost"
              >
                <Copy className="mr-2 h-4 w-4" />
                COPY
              </Button>
              <Button
                className="flex-1 bg-neon-green/20 neon-border-green font-orbitron text-sm hover:bg-neon-green/30 transition-all"
                variant="ghost"
              >
                <Download className="mr-2 h-4 w-4" />
                EXPORT
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
