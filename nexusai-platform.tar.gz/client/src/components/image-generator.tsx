import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Palette, Images, Download, Share, Loader2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function ImageGenerator() {
  const [prompt, setPrompt] = useState("");
  const [model, setModel] = useState("dall-e-3");
  const [aspectRatio, setAspectRatio] = useState("1024x1024");
  const [quality, setQuality] = useState("hd");
  const [style, setStyle] = useState("photorealistic");
  const [result, setResult] = useState<{ url: string } | null>(null);
  const [generatedImages, setGeneratedImages] = useState<{ url: string; prompt: string }[]>([]);
  const { toast } = useToast();

  const generateMutation = useMutation({
    mutationFn: async (data: { prompt: string; model: string; size: string; style: string }) => {
      // Enhance prompt for maximum visual quality
      const qualityEnhancement = ", ultra high resolution, 8K quality, crisp details, sharp focus, professional photography, masterpiece, vibrant colors, perfect composition";
      const enhancedData = {
        ...data,
        prompt: data.prompt + qualityEnhancement,
        quality: "hd"
      };
      const response = await apiRequest("POST", "/api/generate/image", enhancedData);
      return response.json();
    },
    onSuccess: (data) => {
      setResult(data);
      setGeneratedImages(prev => [{ url: data.url, prompt }, ...prev.slice(0, 5)]);
      toast({
        title: "Image Generated",
        description: "Your image has been created successfully!",
        className: "border-neon-blue",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Generation Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleGenerate = () => {
    if (!prompt.trim()) {
      toast({
        title: "Error",
        description: "Please enter a prompt",
        variant: "destructive",
      });
      return;
    }
    generateMutation.mutate({ prompt, model, size: aspectRatio, style });
  };

  const stylePresets = [
    "Photorealistic", "Anime", "Artistic", "Cyberpunk", "Futuristic", "Abstract"
  ];

  return (
    <div className="grid lg:grid-cols-2 gap-8">
      <Card className="bg-cyber-gray/30 neon-border">
        <CardHeader>
          <CardTitle className="text-2xl font-orbitron font-bold text-neon-blue flex items-center">
            <Palette className="mr-3" />
            IMAGE GENERATION
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="block text-sm font-orbitron text-neon-blue mb-2">AI MODEL</label>
            <Select value={model} onValueChange={setModel}>
              <SelectTrigger className="w-full bg-cyber-black neon-border text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-cyber-black border-neon-blue">
                <SelectItem value="dall-e-3">DALL-E 3 HD</SelectItem>
                <SelectItem value="leonardo">Leonardo AI Phoenix (Unlimited)</SelectItem>
                <SelectItem value="midjourney">Midjourney V6</SelectItem>
                <SelectItem value="stable-diffusion">Stable Diffusion XL</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <label className="block text-sm font-orbitron text-neon-blue mb-2">PROMPT</label>
            <Textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              className="w-full h-32 bg-cyber-black neon-border text-white resize-none"
              placeholder="Describe the image you want to create... No content restrictions."
              disabled={generateMutation.isPending}
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-orbitron text-cyber-cyan mb-2">ASPECT RATIO</label>
              <Select value={aspectRatio} onValueChange={setAspectRatio}>
                <SelectTrigger className="w-full bg-cyber-black neon-border text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-cyber-black border-neon-blue">
                  <SelectItem value="1792x1024">16:9 (Landscape)</SelectItem>
                  <SelectItem value="1024x1024">1:1 (Square)</SelectItem>
                  <SelectItem value="1024x1792">9:16 (Portrait)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="block text-sm font-orbitron text-cyber-cyan mb-2">QUALITY</label>
              <Select value={quality} onValueChange={setQuality}>
                <SelectTrigger className="w-full bg-cyber-black neon-border text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-cyber-black border-neon-blue">
                  <SelectItem value="hd">Ultra HD (8K)</SelectItem>
                  <SelectItem value="standard">High (4K)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-orbitron text-neon-purple mb-2">STYLE PRESET</label>
            <div className="grid grid-cols-3 gap-2">
              {stylePresets.map((preset) => (
                <Button
                  key={preset}
                  onClick={() => setStyle(preset.toLowerCase())}
                  className={`bg-cyber-gray/50 neon-border text-xs hover:bg-neon-blue/20 transition-all ${
                    style === preset.toLowerCase() ? "bg-neon-blue/20" : ""
                  }`}
                  variant="ghost"
                  disabled={generateMutation.isPending}
                >
                  {preset}
                </Button>
              ))}
            </div>
          </div>
          
          <Button
            onClick={handleGenerate}
            disabled={generateMutation.isPending}
            className="w-full bg-gradient-to-r from-neon-blue to-neon-purple py-3 font-orbitron font-bold hover:shadow-neon-blue transition-all duration-300"
          >
            {generateMutation.isPending ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Images className="mr-2" />
            )}
            {generateMutation.isPending ? "GENERATING..." : "GENERATE IMAGE"}
          </Button>
        </CardContent>
      </Card>
      
      <Card className="bg-cyber-gray/30 neon-border">
        <CardHeader>
          <CardTitle className="text-2xl font-orbitron font-bold text-neon-blue flex items-center">
            <Images className="mr-3" />
            GENERATED IMAGES
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {generateMutation.isPending ? (
            <div className="bg-cyber-black neon-border rounded-lg p-4 aspect-video flex items-center justify-center">
              <div className="text-center">
                <Loader2 className="mx-auto h-12 w-12 animate-spin text-neon-blue mb-4" />
                <p className="text-neon-blue font-orbitron">Generating your masterpiece...</p>
                <div className="progress-bar h-1 rounded-full mt-4 w-48 mx-auto"></div>
              </div>
            </div>
          ) : result ? (
            <div className="bg-cyber-black neon-border rounded-lg p-4">
              <div className="aspect-video bg-gradient-to-br from-neon-blue/20 to-neon-purple/20 rounded-lg mb-4 overflow-hidden">
                <img
                  src={result.url}
                  alt="Generated image"
                  className="w-full h-full object-cover rounded-lg hover:scale-105 transition-transform duration-300"
                  style={{ imageRendering: 'crisp-edges' }}
                />
              </div>
              <div className="flex justify-between items-center">
                <div className="text-sm">
                  <p className="text-neon-blue">Resolution: {aspectRatio} | Ultra HD Quality</p>
                  <p className="text-neon-green">✓ Professional Grade | ✓ Crisp Details</p>
                </div>
                <div className="flex space-x-2">
                  <Button 
                    className="bg-neon-blue/20 neon-border px-3 py-1 text-xs hover:bg-neon-blue/30 transition-all"
                    variant="ghost"
                    onClick={() => window.open(result.url, '_blank')}
                  >
                    <Download className="h-3 w-3" />
                  </Button>
                  <Button 
                    className="bg-neon-blue/20 neon-border px-3 py-1 text-xs hover:bg-neon-blue/30 transition-all"
                    variant="ghost"
                  >
                    <Share className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-cyber-black neon-border rounded-lg p-4 aspect-video flex items-center justify-center">
              <div className="text-gray-400 text-center">
                <Images className="mx-auto mb-4 h-12 w-12 opacity-50" />
                <p>Generated images will appear here</p>
              </div>
            </div>
          )}
          
          {generatedImages.length > 1 && (
            <div className="grid grid-cols-2 gap-2">
              {generatedImages.slice(1, 5).map((image, index) => (
                <div key={index} className="aspect-square bg-gradient-to-br from-neon-purple/20 to-neon-green/20 rounded-lg overflow-hidden">
                  <img
                    src={image.url}
                    alt={`Generated image ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                </div>
              ))}
            </div>
          )}
          
          <div className="text-center text-sm text-gray-400">
            <p>
              Total Generated: <span className="text-neon-green">{generatedImages.length}</span> | 
              Storage Used: <span className="text-neon-blue">∞ (Unlimited)</span>
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
