import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Volume2, Play, Download, Loader2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function SpeechGenerator() {
  const [text, setText] = useState("");
  const [engine, setEngine] = useState("elevenlabs");
  const [voice, setVoice] = useState("21m00Tcm4TlvDq8ikWAM");
  const [speed, setSpeed] = useState([1]);
  const [pitch, setPitch] = useState([0]);
  const [emotion, setEmotion] = useState("neutral");
  const [result, setResult] = useState<{ filename: string; size: number } | null>(null);
  const { toast } = useToast();

  const voicesQuery = useQuery({
    queryKey: ["/api/voices"],
    enabled: engine === "elevenlabs",
  });

  const generateMutation = useMutation({
    mutationFn: async (data: { text: string; engine: string; voice: string }) => {
      const response = await apiRequest("POST", "/api/generate/speech", data);
      return response.json();
    },
    onSuccess: (data) => {
      setResult(data);
      toast({
        title: "Speech Generated",
        description: "Audio has been generated successfully!",
        className: "border-neon-purple",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Generation Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleGenerate = () => {
    if (!text.trim()) {
      toast({
        title: "Error",
        description: "Please enter text to synthesize",
        variant: "destructive",
      });
      return;
    }
    generateMutation.mutate({ text, engine, voice });
  };

  const handleDownload = () => {
    if (result) {
      window.open(`/api/files/${result.filename}`, '_blank');
    }
  };

  return (
    <div className="grid lg:grid-cols-2 gap-8">
      <Card className="bg-cyber-gray/30 neon-border-purple">
        <CardHeader>
          <CardTitle className="text-2xl font-orbitron font-bold text-neon-purple flex items-center">
            <Volume2 className="mr-3" />
            SPEECH SYNTHESIS
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="block text-sm font-orbitron text-neon-purple mb-2">TTS ENGINE</label>
            <Select value={engine} onValueChange={setEngine}>
              <SelectTrigger className="w-full bg-cyber-black neon-border-purple text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-cyber-black border-neon-purple">
                <SelectItem value="elevenlabs">ElevenLabs Premium (Unlimited)</SelectItem>
                <SelectItem value="openai">OpenAI TTS HD</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <label className="block text-sm font-orbitron text-neon-purple mb-2">VOICE MODEL</label>
            <Select value={voice} onValueChange={setVoice}>
              <SelectTrigger className="w-full bg-cyber-black neon-border-purple text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-cyber-black border-neon-purple">
                {engine === "elevenlabs" && voicesQuery.data && Array.isArray(voicesQuery.data) ? (
                  voicesQuery.data.map((v: any) => (
                    <SelectItem key={v.voice_id} value={v.voice_id}>
                      {v.name}
                    </SelectItem>
                  ))
                ) : (
                  <>
                    <SelectItem value="alloy">Alloy (Neural)</SelectItem>
                    <SelectItem value="echo">Echo (Professional)</SelectItem>
                    <SelectItem value="fable">Fable (Expressive)</SelectItem>
                    <SelectItem value="nova">Nova (Conversational)</SelectItem>
                  </>
                )}
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <label className="block text-sm font-orbitron text-neon-purple mb-2">TEXT TO SPEECH</label>
            <Textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              className="w-full h-32 bg-cyber-black neon-border-purple text-white resize-none"
              placeholder="Enter text to convert to speech... Unlimited length supported."
              disabled={generateMutation.isPending}
            />
          </div>
          
          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-orbitron text-cyber-cyan mb-2">
                SPEED: {speed[0]}
              </label>
              <Slider
                value={speed}
                onValueChange={setSpeed}
                max={2}
                min={0.5}
                step={0.1}
                className="w-full"
                disabled={generateMutation.isPending}
              />
            </div>
            <div>
              <label className="block text-sm font-orbitron text-cyber-cyan mb-2">
                PITCH: {pitch[0]}
              </label>
              <Slider
                value={pitch}
                onValueChange={setPitch}
                max={10}
                min={-10}
                step={1}
                className="w-full"
                disabled={generateMutation.isPending}
              />
            </div>
            <div>
              <label className="block text-sm font-orbitron text-cyber-cyan mb-2">EMOTION</label>
              <Select value={emotion} onValueChange={setEmotion}>
                <SelectTrigger className="w-full bg-cyber-black neon-border text-white text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-cyber-black border-neon-blue">
                  <SelectItem value="neutral">Neutral</SelectItem>
                  <SelectItem value="excited">Excited</SelectItem>
                  <SelectItem value="calm">Calm</SelectItem>
                  <SelectItem value="dramatic">Dramatic</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <Button
            onClick={handleGenerate}
            disabled={generateMutation.isPending}
            className="w-full bg-gradient-to-r from-neon-purple to-cyber-magenta py-3 font-orbitron font-bold hover:shadow-neon-purple transition-all duration-300"
          >
            {generateMutation.isPending ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Play className="mr-2" />
            )}
            {generateMutation.isPending ? "SYNTHESIZING..." : "SYNTHESIZE VOICE"}
          </Button>
        </CardContent>
      </Card>
      
      <Card className="bg-cyber-gray/30 neon-border-purple">
        <CardHeader>
          <CardTitle className="text-2xl font-orbitron font-bold text-neon-purple flex items-center">
            <Volume2 className="mr-3" />
            AUDIO OUTPUT
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="bg-cyber-black neon-border-purple rounded-lg p-6 h-64 flex flex-col justify-center items-center">
            {generateMutation.isPending ? (
              <div className="text-center">
                <div className="flex items-center justify-center space-x-1 mb-6">
                  {[...Array(8)].map((_, i) => (
                    <div
                      key={i}
                      className="w-1 bg-neon-purple rounded-full animate-pulse"
                      style={{
                        height: `${Math.random() * 30 + 15}px`,
                        animationDelay: `${i * 0.1}s`,
                      }}
                    />
                  ))}
                </div>
                <p className="text-neon-purple font-orbitron">Generating Audio...</p>
              </div>
            ) : result ? (
              <div className="w-full max-w-md text-center">
                <div className="flex items-center justify-center space-x-1 mb-6">
                  {[...Array(8)].map((_, i) => (
                    <div
                      key={i}
                      className="w-1 bg-neon-purple rounded-full"
                      style={{ height: `${Math.random() * 30 + 15}px` }}
                    />
                  ))}
                </div>
                
                <div className="text-center text-neon-purple font-orbitron mb-4">
                  <p className="text-sm">Size: {Math.round(result.size / 1024)}KB | Studio Quality</p>
                  <p className="text-xs text-neon-green">✓ High Fidelity | ✓ Crystal Clear</p>
                </div>
                
                <div className="flex justify-center space-x-4">
                  <Button className="bg-neon-purple/20 neon-border-purple rounded-full w-12 h-12 hover:bg-neon-purple/30 transition-all">
                    <Play className="text-neon-purple" />
                  </Button>
                  <Button 
                    onClick={handleDownload}
                    className="bg-neon-purple/20 neon-border-purple rounded-full w-12 h-12 hover:bg-neon-purple/30 transition-all"
                  >
                    <Download className="text-neon-purple" />
                  </Button>
                </div>
              </div>
            ) : (
              <div className="text-gray-400 text-center">
                <Volume2 className="mx-auto mb-4 h-12 w-12 opacity-50" />
                <p>Generated audio will appear here</p>
              </div>
            )}
          </div>
          
          {result && (
            <div className="mt-4 space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-400">Generation Status:</span>
                <span className="text-neon-green">Complete</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">API Cost:</span>
                <span className="text-neon-green">$0.00 (Unlimited)</span>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
