import { useState } from "react";
import Header from "@/components/header";
import Footer from "@/components/footer";
import TextGenerator from "@/components/text-generator";
import SpeechGenerator from "@/components/speech-generator";
import VoiceClone from "@/components/voice-clone";
import ImageGenerator from "@/components/image-generator";
import AnimationGenerator from "@/components/animation-generator";
import { Button } from "@/components/ui/button";
import { Microchip, Infinity, Zap, Shield, Rocket } from "lucide-react";

export default function Home() {
  const [activeTab, setActiveTab] = useState("text");

  const tabs = [
    { id: "text", label: "TEXT AI", icon: "fas fa-pen-fancy" },
    { id: "speech", label: "SPEECH AI", icon: "fas fa-microphone" },
    { id: "voice-clone", label: "VOICE CLONE", icon: "fas fa-user-secret" },
    { id: "image", label: "IMAGE AI", icon: "fas fa-image" },
    { id: "animation", label: "ANIMATION", icon: "fas fa-film" },
  ];

  return (
    <div className="min-h-screen bg-cyber-black text-white cyber-grid">
      <Header />
      
      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-b from-cyber-gray/50 to-cyber-black">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-5xl md:text-7xl font-orbitron font-black mb-6">
            <span className="bg-gradient-to-r from-neon-blue via-neon-purple to-neon-green bg-clip-text text-transparent animate-pulse-neon">
              BREAK THE LIMITS
            </span>
          </h2>
          <p className="text-xl md:text-2xl text-gray-300 mb-8 max-w-4xl mx-auto">
            Unlimited AI content generation with zero restrictions. Text, speech, images, and animations powered by{" "}
            <span className="text-neon-blue">ChatGPT</span>, <span className="text-neon-purple">Grok</span>,{" "}
            <span className="text-neon-green">Leonardo</span>, and more.
          </p>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto mb-12">
            <div className="bg-cyber-gray/30 neon-border rounded-lg p-4 hover-glow transition-all duration-300">
              <Infinity className="w-8 h-8 text-neon-blue mb-2 mx-auto" />
              <p className="text-sm font-orbitron">UNLIMITED</p>
              <p className="text-xs text-gray-400">No Tokens Required</p>
            </div>
            <div className="bg-cyber-gray/30 neon-border-purple rounded-lg p-4 hover-glow transition-all duration-300">
              <Zap className="w-8 h-8 text-neon-purple mb-2 mx-auto" />
              <p className="text-sm font-orbitron">ULTRA HD</p>
              <p className="text-xs text-gray-400">8K Image Quality</p>
            </div>
            <div className="bg-cyber-gray/30 neon-border-green rounded-lg p-4 hover-glow transition-all duration-300">
              <Shield className="w-8 h-8 text-neon-green mb-2 mx-auto" />
              <p className="text-sm font-orbitron">STUDIO GRADE</p>
              <p className="text-xs text-gray-400">Professional Audio</p>
            </div>
            <div className="bg-cyber-gray/30 neon-border rounded-lg p-4 hover-glow transition-all duration-300">
              <Rocket className="w-8 h-8 text-cyber-cyan mb-2 mx-auto" />
              <p className="text-sm font-orbitron">4K VIDEO</p>
              <p className="text-xs text-gray-400">Cinema Quality</p>
            </div>
          </div>
        </div>
      </section>

      {/* Main Interface */}
      <main className="container mx-auto px-4 py-12">
        {/* Tab Navigation */}
        <div className="flex flex-wrap justify-center mb-8 bg-cyber-gray/30 neon-border rounded-xl p-2">
          {tabs.map((tab) => (
            <Button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-6 py-3 m-1 rounded-lg font-orbitron text-sm transition-all duration-300 flex items-center space-x-2 ${
                activeTab === tab.id
                  ? "tab-active"
                  : "bg-transparent hover:bg-cyber-gray/50 border-transparent"
              }`}
              variant="ghost"
            >
              <i className={tab.icon}></i>
              <span>{tab.label}</span>
            </Button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="tab-content">
          {activeTab === "text" && <TextGenerator />}
          {activeTab === "speech" && <SpeechGenerator />}
          {activeTab === "voice-clone" && <VoiceClone />}
          {activeTab === "image" && <ImageGenerator />}
          {activeTab === "animation" && <AnimationGenerator />}
        </div>
      </main>

      <Footer />
    </div>
  );
}
