import { apiRequest } from "./queryClient";

export interface GenerationRequest {
  prompt: string;
  model?: string;
  parameters?: Record<string, any>;
}

export interface GenerationResponse {
  id: number;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  result?: any;
}

export const api = {
  // Text generation
  generateText: async (data: GenerationRequest): Promise<GenerationResponse> => {
    const response = await apiRequest("POST", "/api/generate/text", data);
    return response.json();
  },

  // Speech generation
  generateSpeech: async (data: GenerationRequest): Promise<GenerationResponse> => {
    const response = await apiRequest("POST", "/api/generate/speech", data);
    return response.json();
  },

  // Image generation
  generateImage: async (data: GenerationRequest): Promise<GenerationResponse> => {
    const response = await apiRequest("POST", "/api/generate/image", data);
    return response.json();
  },

  // Animation generation
  generateAnimation: async (data: GenerationRequest): Promise<GenerationResponse> => {
    const response = await apiRequest("POST", "/api/generate/animation", data);
    return response.json();
  },

  // Voice cloning
  uploadVoiceSamples: async (formData: FormData): Promise<any> => {
    const response = await fetch("/api/voice-clone/upload", {
      method: "POST",
      body: formData,
    });
    if (!response.ok) throw new Error("Upload failed");
    return response.json();
  },

  // Get generation status
  getGeneration: async (id: number): Promise<GenerationResponse> => {
    const response = await apiRequest("GET", `/api/generation/${id}`, undefined);
    return response.json();
  },

  // Get available voices
  getVoices: async (): Promise<any[]> => {
    const response = await apiRequest("GET", "/api/voices", undefined);
    return response.json();
  },

  // Get voice models
  getVoiceModels: async (): Promise<any[]> => {
    const response = await apiRequest("GET", "/api/voice-clone/models", undefined);
    return response.json();
  },
};
