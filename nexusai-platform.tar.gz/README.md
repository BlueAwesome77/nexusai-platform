# NexusAI - Multi-Modal AI Content Generation Platform

A comprehensive AI platform providing text, image, and speech generation services with a professional cyberpunk-themed interface.

## Features

- **Text Generation**: X.AI/Grok and OpenAI integration
- **Image Generation**: Stability AI (SDXL) with OpenAI fallback
- **Speech Synthesis**: ElevenLabs with multiple voice options
- **Voice Cloning**: Custom voice training capabilities
- **Professional UI**: Cyberpunk-themed responsive design

## Prerequisites

- Node.js (v18 or higher)
- PostgreSQL database (optional - can use memory storage)
- API Keys for AI services

## API Keys Required

1. **X.AI/Grok**: Get from https://console.x.ai/
2. **OpenAI**: Get from https://platform.openai.com/api-keys
3. **Stability AI**: Get from https://platform.stability.ai/account/keys
4. **ElevenLabs**: Get from https://elevenlabs.io/app/settings/api-keys

## Installation

1. Clone or download this repository
2. Install dependencies:
   ```bash
   npm install
   ```

3. Create environment variables file (`.env`):
   ```env
   # Database (optional - uses memory storage if not provided)
   DATABASE_URL=postgresql://username:password@localhost:5432/database

   # AI Service API Keys
   OPENAI_API_KEY=sk-your-openai-key
   XAI_API_KEY=xai-your-xai-key
   STABILITY_API_KEY=sk-your-stability-key
   ELEVENLABS_API_KEY=your-elevenlabs-key
   ```

4. Run the application:
   ```bash
   npm run dev
   ```

5. Open http://localhost:5000 in your browser

## Project Structure

```
├── client/          # Frontend React application
├── server/          # Backend Express server
├── shared/          # Shared types and schemas
├── uploads/         # Generated audio files
└── README.md        # This file
```

## API Endpoints

- `POST /api/generate/text` - Generate text content
- `POST /api/generate/image` - Generate images
- `POST /api/generate/speech` - Generate speech audio
- `POST /api/voice-clone/upload` - Upload voice samples for cloning
- `GET /api/voices` - Get available voices
- `GET /api/health` - Health check

## Usage Costs

- Text: ~$0.02 per generation
- Images: ~$0.04-0.08 per generation  
- Speech: ~$0.01-0.03 per generation

## Billing Setup

Each AI service requires billing setup:

1. **X.AI**: Add credits at https://console.x.ai/team/billing
2. **OpenAI**: Add credits at https://platform.openai.com/account/billing  
3. **Stability AI**: Add credits at https://platform.stability.ai/account/billing
4. **ElevenLabs**: Subscribe at https://elevenlabs.io/subscription

## Free Distribution

This platform is provided free for personal and educational use. Users are responsible for their own AI service costs.

## Support

For issues or questions, refer to the respective AI service documentation:
- [OpenAI Docs](https://platform.openai.com/docs)
- [X.AI Docs](https://docs.x.ai/)
- [Stability AI Docs](https://platform.stability.ai/docs)
- [ElevenLabs Docs](https://docs.elevenlabs.io/)

## License

Open source - feel free to modify and distribute.