// NexusAI Platform Demo Script
// This script demonstrates the working functionality

async function demoTextGeneration() {
  const response = await fetch('/api/generate/text', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      prompt: "Create a futuristic story about AI and humanity",
      model: "grok-2-1212",
      temperature: 0.8
    })
  });
  return response.json();
}

async function demoSpeechGeneration() {
  const response = await fetch('/api/generate/speech', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      text: "This is a demonstration of professional voice synthesis",
      engine: "elevenlabs",
      voice: "21m00Tcm4TlvDq8ikWAM"
    })
  });
  return response.json();
}

async function getVoices() {
  const response = await fetch('/api/voices');
  return response.json();
}

console.log('NexusAI Demo Ready - ElevenLabs Voice System Active');