import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertGenerationSchema, insertVoiceModelSchema } from "@shared/schema";
import { generateText, generateImage, generateSpeech } from "./ai-services/openai";
import { generateImageWithStability } from "./ai-services/stability";
import { generateTextWithGrok } from "./ai-services/grok";
import { generateSpeechElevenLabs, cloneVoice, getAvailableVoices } from "./ai-services/elevenlabs";
import multer from "multer";
import path from "path";
import fs from "fs";

const upload = multer({ 
  dest: "uploads/",
  limits: { fileSize: 50 * 1024 * 1024 } // 50MB limit
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({ 
      status: "ok", 
      timestamp: new Date().toISOString(),
      services: {
        openai: !!process.env.OPENAI_API_KEY,
        xai: !!process.env.XAI_API_KEY,
        elevenlabs: !!process.env.ELEVENLABS_API_KEY
      }
    });
  });
  
  // Text generation endpoint
  app.post("/api/generate/text", async (req, res) => {
    try {
      const { prompt, model, temperature } = req.body;
      
      if (!prompt) {
        return res.status(400).json({ error: "Prompt is required" });
      }

      console.log("Processing text generation request:", { prompt: prompt.substring(0, 50), model, temperature });
      console.log("API Keys status:", {
        openai: process.env.OPENAI_API_KEY ? `${process.env.OPENAI_API_KEY.substring(0, 7)}...` : "missing",
        xai: process.env.XAI_API_KEY ? `${process.env.XAI_API_KEY.substring(0, 7)}...` : "missing"
      });

      const generation = await storage.createGeneration({
        type: "text",
        prompt,
        model: model || "gpt-4o",
        parameters: { temperature: temperature || 0.8 },
        status: "processing",
        userId: null,
        result: null,
      });

      // Generate text using available services
      let result;
      let primaryError = null;
      let fallbackError = null;

      // First, try Grok/X.AI if specifically requested or as primary option
      if (model?.includes("grok") || !process.env.OPENAI_API_KEY) {
        try {
          result = await generateTextWithGrok(prompt, model || "grok-2-1212", temperature);
        } catch (error: any) {
          primaryError = error;
          console.log("Grok API failed:", error.message);
        }
      }

      // If Grok failed or wasn't tried, try OpenAI
      if (!result && process.env.OPENAI_API_KEY) {
        try {
          result = await generateText(prompt, model?.replace("grok", "gpt-4o") || "gpt-4o", temperature);
        } catch (error: any) {
          fallbackError = error;
          console.log("OpenAI API failed:", error.message);
        }
      }

      // If both failed or OpenAI wasn't available, try Grok as final fallback
      if (!result && !primaryError && process.env.XAI_API_KEY) {
        try {
          result = await generateTextWithGrok(prompt, "grok-2-1212", temperature);
        } catch (error: any) {
          fallbackError = error;
          console.log("Grok fallback failed:", error.message);
        }
      }

      if (!result) {
        const errorMsg = primaryError || fallbackError;
        throw new Error(`All AI services failed: ${errorMsg?.message || "Unknown error"}`);
      }

      await storage.updateGeneration(generation.id, {
        status: "completed",
        result: { text: result }
      });

      res.json({ 
        id: generation.id,
        text: result,
        status: "completed"
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Speech generation endpoint
  app.post("/api/generate/speech", async (req, res) => {
    try {
      const { text, engine, voice } = req.body;
      
      if (!text) {
        return res.status(400).json({ error: "Text is required" });
      }

      const generation = await storage.createGeneration({
        type: "speech",
        prompt: text,
        model: engine || "elevenlabs",
        parameters: { voice },
        status: "processing",
        userId: null,
        result: null,
      });

      let audioBuffer;
      if (engine === "elevenlabs") {
        try {
          audioBuffer = await generateSpeechElevenLabs(text, voice);
        } catch (error: any) {
          console.log("ElevenLabs API failed:", error.message);
          // Fallback to OpenAI if ElevenLabs fails
          if (process.env.OPENAI_API_KEY) {
            audioBuffer = await generateSpeech(text, voice || "alloy");
          } else {
            throw new Error("No available speech service. Please check your API keys and credits.");
          }
        }
      } else {
        // Try OpenAI first, then fallback to ElevenLabs
        try {
          if (process.env.OPENAI_API_KEY) {
            audioBuffer = await generateSpeech(text, voice || "alloy");
          } else {
            audioBuffer = await generateSpeechElevenLabs(text, "21m00Tcm4TlvDq8ikWAM");
          }
        } catch (error: any) {
          console.log("Primary speech service failed:", error.message);
          // Try the other service as fallback
          try {
            if (process.env.ELEVENLABS_API_KEY) {
              audioBuffer = await generateSpeechElevenLabs(text, "21m00Tcm4TlvDq8ikWAM");
            } else {
              throw new Error("No available speech service. Please check your API keys and credits.");
            }
          } catch (fallbackError: any) {
            console.log("Fallback speech service also failed:", fallbackError.message);
            throw new Error("All speech services are unavailable. Please check your API keys and credits.");
          }
        }
      }

      // Save audio file
      const filename = `speech_${generation.id}.mp3`;
      const filepath = path.join("uploads", filename);
      fs.writeFileSync(filepath, audioBuffer);

      await storage.updateGeneration(generation.id, {
        status: "completed",
        result: { filename, size: audioBuffer.length }
      });

      res.json({ 
        id: generation.id,
        filename,
        size: audioBuffer.length,
        status: "completed"
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Voice cloning endpoints
  app.post("/api/voice-clone/upload", upload.array("samples"), async (req, res) => {
    try {
      const { name } = req.body;
      const files = req.files as Express.Multer.File[];
      
      if (!name || !files || files.length === 0) {
        return res.status(400).json({ error: "Name and audio samples are required" });
      }

      const voiceModel = await storage.createVoiceModel({
        name,
        status: "training",
        sampleFiles: files.map(f => f.path),
        elevenLabsVoiceId: null,
        userId: null,
      });

      // Start voice cloning process
      const audioBuffers = files.map(f => fs.readFileSync(f.path));
      const voiceId = await cloneVoice(name, audioBuffers);

      await storage.updateVoiceModel(voiceModel.id, {
        status: "ready",
        elevenLabsVoiceId: voiceId
      });

      res.json({ 
        id: voiceModel.id,
        name,
        status: "ready",
        voiceId
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/voice-clone/models", async (req, res) => {
    try {
      const models = await storage.getVoiceModelsByUser(1); // For now, use user ID 1
      res.json(models);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Image generation endpoint
  app.post("/api/generate/image", async (req, res) => {
    try {
      const { prompt, model, size, style } = req.body;
      
      if (!prompt) {
        return res.status(400).json({ error: "Prompt is required" });
      }

      const generation = await storage.createGeneration({
        type: "image",
        prompt,
        model: model || "dall-e-3",
        parameters: { size, style },
        status: "processing",
        userId: null,
        result: null,
      });

      // Generate image with fallback to Stability AI
      let result;
      let primaryError = null;
      
      // Try OpenAI first
      try {
        result = await generateImage(prompt, size, "hd");
      } catch (error: any) {
        primaryError = error;
        console.log("OpenAI image generation failed:", error.message);
      }
      
      // Fallback to Stability AI if OpenAI fails
      if (!result && process.env.STABILITY_API_KEY) {
        try {
          result = await generateImageWithStability(prompt, 1024, 1024);
        } catch (error: any) {
          console.log("Stability AI fallback failed:", error.message);
        }
      }
      
      if (!result) {
        throw new Error(`Image generation failed: ${primaryError?.message || "All services unavailable"}`);
      }

      await storage.updateGeneration(generation.id, {
        status: "completed",
        result: { url: result.url }
      });

      res.json({ 
        id: generation.id,
        url: result.url,
        status: "completed"
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Animation generation endpoint (placeholder for Kling AI integration)
  app.post("/api/generate/animation", async (req, res) => {
    try {
      const { prompt, duration, fps, cameraMovement } = req.body;
      
      if (!prompt) {
        return res.status(400).json({ error: "Prompt is required" });
      }

      const generation = await storage.createGeneration({
        type: "animation",
        prompt,
        model: "kling-ai",
        parameters: { duration, fps, cameraMovement },
        status: "processing",
        userId: null,
        result: null,
      });

      // Simulate animation generation (would integrate with Kling AI)
      setTimeout(async () => {
        await storage.updateGeneration(generation.id, {
          status: "completed",
          result: { 
            url: "https://example.com/generated-video.mp4",
            duration: duration || 10,
            fps: fps || 30
          }
        });
      }, 5000);

      res.json({ 
        id: generation.id,
        status: "processing",
        estimatedTime: "2-5 minutes"
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get generation status
  app.get("/api/generation/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const generation = await storage.getGeneration(id);
      
      if (!generation) {
        return res.status(404).json({ error: "Generation not found" });
      }

      res.json(generation);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Serve generated files
  app.get("/api/files/:filename", (req, res) => {
    const filename = req.params.filename;
    const filepath = path.join("uploads", filename);
    
    if (fs.existsSync(filepath)) {
      res.sendFile(path.resolve(filepath));
    } else {
      res.status(404).json({ error: "File not found" });
    }
  });

  // Get available voices
  app.get("/api/voices", async (req, res) => {
    try {
      const voices = await getAvailableVoices();
      res.json(voices);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
